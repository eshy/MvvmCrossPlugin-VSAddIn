﻿namespace $safeprojectname$
{
    public interface IMvx$ext_pluginname$

    {
        
    }
}