using $ext_safeprojectname$.Core;

namespace $safeprojectname$
{
    public class Mvx$ext_safeprojectname$ : IMvx$ext_safeprojectname$
    {
    }
}
