﻿using $ext_safeprojectname$.Core;

namespace $safeprojectname$
{
    public class Mvx$ext_pluginname$ : IMvx$ext_pluginname$
    {
    }
}
